// Carregando módulos
    const express = require('express')
    const handlebars = require('express-handlebars')
    const bodyParser = require('body-parser')
    const mongoose = require('mongoose')
    const path = require("path")
    const session = require('express-session')
    const flash = require('connect-flash')

    const admin = require('./routes/admin')
    const usuarios = require('./routes/usuarios')

    require('./models/Postagem')
    const Postagem = mongoose.model("postagens")

    require('./models/Categoria')
    const Categoria = mongoose.model("categorias")

    const app = express()


    

// Configurações

    //Sessão
        app.use(session({
            secret: "topz",
            resave: true,
            saveUninitialized: true,
        }))
        app.use(flash())

    // Middleware
        app.use((req, res, next) => {
            res.locals.success_msg = req.flash("success_msg")
            res.locals.error_msg = req.flash("error_msg")
            next()
        })

    //Body-Parser
        app.use(bodyParser.urlencoded({extended: true}))
        app.use(bodyParser.json())

    //Handlebars
        app.engine('handlebars', handlebars({default: true}))
        app.set('view engine', 'handlebars');

    // Mongoose
        mongoose.Promise = global.Promise;
        mongoose.connect("mongodb://localhost/NodeJS", {
            useNewUrlParser: true, 
            useUnifiedTopology: true
        }).then(() => {
            console.log("Conectado ao mongodb")
        }).catch((err) => {
            console.log("Ocorreu um erro: " + err)
        })

    //Public
        app.use(express.static(path.join(__dirname, 'public')))

// Rotas
    app.get('/', (req, res) => {
        Postagem.find().populate("categoria").sort({data: "desc"}).then((postagens) => {
            res.render('index', {postagens: postagens.map(Postagem => Postagem.toJSON())})
        }).catch((err) => {
            req.flash("error_msg", "Não foi possivel exibir postagens")
            res.redirect('/404')
        })
        
    })

    app.get('/postagem/:slug', (req, res) => {
        Postagem.find({slug: req.params.slug}).then((postagem) => {
            if(postagem){
                const newPostagem = postagem.map(Postagem => Postagem.toJSON());
                res.render("postagem/index", {postagem: newPostagem[0]})
            }
            else{
                req.flash("error_msg", "Não foi abrir postagem")
                res.redirect('/')
            }
        }).catch((err) => {
            req.flash("error_msg", "Erro na postagem")
            res.redirect('/')
        })
    })

    app.get('/categorias', (req, res) => {
        Categoria.find().sort({data: "desc"}).then((categorias) => {
            res.render('categorias/index', {categorias: categorias.map(Categoria => Categoria.toJSON())})
        }).catch((err) => {
            req.flash("error_msg", "Não foi possivel exibir postagens")
            res.redirect('/')
        })
    })

    app.get("/categorias/:slug", (req, res) => {
        Categoria.findOne({slug: req.params.slug}).lean().then((categoria) => {
            if(categoria){
                Postagem.find({categoria: categoria._id}).lean().then((postagens) => {
                    res.render("categorias/postagens", {categoria: categoria, postagens: postagens})

                }).catch((err) => {
                    req.flash("error_msg", "Erro ao listar postagens")
                    res.redirect('/')
                })
            }
            else{
                req.flash("error_msg", "Postagens da categoria indisponiveis")
            res.redirect('/')
            }
        }).catch((err) => {
            req.flash("error_msg", "Categoria indisponivel")
            res.redirect('/')
        })
    })











    app.get('/404', (req, res) => {
        req.flash("error_msg", "Erro interno :(")
    })

    app.use('/admin', admin)

    app.use('/usuarios', usuarios)

// Outros
    const PORT = 8081
    app.listen(PORT, () => {
        console.log("Servidor funcionando :)")
    })