const express = require('express')
const router = express.Router()
const mongoose = require('mongoose')
const bcrypt = require("bcryptjs")

require("../models/Usuario")
const Usuario = mongoose.model("usuarios")


router.get('/registro', (req, res) => {
    res.render("usuarios/registro")
})

router.post('/registro', (req, res) => {
    var erros = []

    if(!req.body.nome || typeof req.body.nome == undefined || req.body.nome == null){
        erros.push({text: "Nome invalido"})
    }

    if(!req.body.email || typeof req.body.email == undefined || req.body.email == null){
        erros.push({text: "Email invalido"})
    }

    if(!req.body.senha || typeof req.body.senha == undefined || req.body.senha == null){
        erros.push({text: "Senha invalido"})
    }
    
    if(req.body.senha.length < 4){
        erros.push({text: "Senha muito pequena"})
    }

     if(req.body.senha != req.body.senha2){
        erros.push({text: "Senhas incompativeis"})
    }

    if(erros.length > 0){
        res.render("usuarios/registro", {erros: erros})
    }else{

        Usuario.findOne({email: req.body.email}).then((usuario) => {
            if(usuario){
                req.flash("error_msg", "usuario já registrado"),
            res.redirect("/")
            }else{

                const novoUsuario = new Usuario({
                    nome: req.body.nome,
                    email: req.body.email,
                    senha: req.body.senha
                })

                bcrypt.genSalt(10, (erro, salt) => {
                    bcrypt.hash(novoUsuario.senha, salt, (erro, hash) => {
                        if(erro){
                            req.flash("erro_msg", "Erro ao salvar o usuario")
                            res.redirect("/")
                        }

                        novoUsuario.senha = hash

                        novoUsuario.save().then(() => {
                            req.flash("success_msg", "Usuario salvo")
                            res.redirect("/")
                        }).catch((err) => {
                            req.flash("erro_msg", "Erro ao registrar o usuario")
                            res.redirect("/")
                        })
                    })
                })

            }
        }).catch(() => [
            req.flash("error_msg", "erro interno"),
            res.redirect("/")
        ])

    }

   
})

module.exports = router